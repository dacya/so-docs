#include <stdio.h>
#include <stdlib.h>

void copy(int fdo, int fdd)
{

}

int main(int argc, char *argv[])
{

	return 0;
}
