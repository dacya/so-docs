#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main(void)
{
    int fd1,fd2,i,pos;
    char c;
    char buffer[6];

    fd1 = open("output.txt", O_CREAT | O_TRUNC | O_RDWR, S_IRUSR | S_IWUSR);
    
    // In this exercise, we are going to create 10 processes (one parent and 9 children) and we are going to make them all write to the same file.
    // Option A - The parent will create a text file ("output.txt") in which each process will write its corresponding creation number ( the parent 0, and the children the numbers 1-9) a certain number of times. 
    //// So the content of the file at the end will be: 000001111111222222233333334444444555555566666667777777888889999999
    // Option B - the parent writes its number between the writing of the children, so the content of the file at the end will be:
    //// 000001111100000222220000033333000004444400000555550000066666000007777700000888880000099999


    lseek(fd1, 0, SEEK_SET);
    printf("File contents are:\n");
    while (read(fd1, &c, 1) > 0)
        printf("%c", (char) c);
    printf("\n");
    close(fd1);
    exit(0);
}
