#include <stdio.h>
#include <stdlib.h>


/*programa que temporiza la ejecución de un proceso hijo */


int main(int argc, char **argv)
{

	return 0;
}
