#include <stdio.h>
#include <stdlib.h>

void copy(int fdo, int fdd)
{

}

void copy_regular(char *orig, char *dest)
{

}

void copy_link(char *orig, char *dest)
{

}

int main(int argc, char *argv[])
{

	return 0;
}
