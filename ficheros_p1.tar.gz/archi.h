#define VAR 100

