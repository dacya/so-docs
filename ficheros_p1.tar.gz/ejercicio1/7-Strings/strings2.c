#include <stdio.h>
#include <string.h>

void copia2(char* org, char** dst)
{
	*dst = org;
}

void copia(char* org, char* dst)
{
	dst = org;
}

void mod(char* org, char* dst)
{
	int i;

	for (i=0;i<strlen(org);i++)
		dst[i] = org[i] - 32;
}

int main()
{
	char* cad1 = "original";
	char* cad2 = "otra";
	char cad3[32];

	copia(cad1,cad2);
	//copia2(cad1, &cad2);
	printf("cad1 %s cad2 %s\n", cad1, cad2);

	mod(cad1, cad3);
	printf("cad1 %s cad3 %s\n", cad1,cad3);

	//mod(cad1, cad1);
	return 0;
}

